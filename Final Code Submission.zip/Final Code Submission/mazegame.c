#include <SDL2/SDL.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <stdbool.h>

#define WIDTH 10
#define HEIGHT 10
#define CELL_SIZE 60
#define MAX_KEYS 12
#define CHECK_RANGE 4
#define VISIBILITY_RANGE 2
#define CHECK_DURATION 500 // 500ms for check effect

typedef struct {
    int visited;
    int north, south, east, west;
} Cell;

typedef struct {
    int x, y;
    int direction; // 0:North, 1:East, 2:South, 3:West
    int keyCount;
    bool isVisible;
    SDL_Color color;
} Player;

typedef struct {
    int x, y;
    bool isVisible;
    bool isCollected;
} Key;

typedef struct {
    bool isCheckActive;
    Uint32 checkStartTime;
    int checkX, checkY;
    int checkDirection;
} CheckEffect;

// Global variables
Cell maze[WIDTH][HEIGHT];
Player players[2];
Key keys[MAX_KEYS];
int currentPlayer = 0;
int stepsRemaining = 10;
CheckEffect checkEffect = {false, 0, 0, 0, 0};

// Function declarations
void initializeMaze();
void carvePath(int x, int y);
void initializePlayers();
void initializeKeys();
void renderMaze(SDL_Renderer* renderer);
void renderPlayers(SDL_Renderer* renderer);
void renderKeys(SDL_Renderer* renderer);
void renderTurnIndicator(SDL_Renderer* renderer);
void renderCheckEffect(SDL_Renderer* renderer);
bool canMove(int x, int y, int direction);
void movePlayer(int playerIndex, int direction);
void updateKeyVisibility();
void collectKeys();
bool checkForOpponent();
void respawnKey(int keyIndex);
void drawPumpkin(SDL_Renderer* renderer, int x, int y);
void drawPlayerArrow(SDL_Renderer* renderer, Player player);

// Initialize maze
void initializeMaze() {
    for (int x = 0; x < WIDTH; x++) {
        for (int y = 0; y < HEIGHT; y++) {
            maze[x][y].visited = 0;
            maze[x][y].north = 1;
            maze[x][y].south = 1;
            maze[x][y].east = 1;
            maze[x][y].west = 1;
        }
    }
}

// Carve paths in maze
void carvePath(int x, int y) {
    maze[x][y].visited = 1;
    int directions[4][2] = {{0, -1}, {0, 1}, {1, 0}, {-1, 0}};
    int randomOrder[4] = {0, 1, 2, 3};
    
    for (int i = 0; i < 4; i++) {
        int j = rand() % 4;
        int temp = randomOrder[i];
        randomOrder[i] = randomOrder[j];
        randomOrder[j] = temp;
    }
    
    for (int i = 0; i < 4; i++) {
        int dir = randomOrder[i];
        int nx = x + directions[dir][0];
        int ny = y + directions[dir][1];
        
        if (nx >= 0 && nx < WIDTH && ny >= 0 && ny < HEIGHT && !maze[nx][ny].visited) {
            if (dir == 0) {
                maze[x][y].north = 0;
                maze[nx][ny].south = 0;
            } else if (dir == 1) {
                maze[x][y].south = 0;
                maze[nx][ny].north = 0;
            } else if (dir == 2) {
                maze[x][y].east = 0;
                maze[nx][ny].west = 0;
            } else if (dir == 3) {
                maze[x][y].west = 0;
                maze[nx][ny].east = 0;
            }
            carvePath(nx, ny);
        }
    }
}

void addExtraConnections(void) {
    int numExtraConnections = (WIDTH * HEIGHT) / 4; // Add 25% more connections
    
    for (int i = 0; i < numExtraConnections; i++) {
        int x = rand() % (WIDTH - 1);
        int y = rand() % (HEIGHT - 1);
        
        // Randomly choose between removing horizontal or vertical wall
        if (rand() % 2 == 0) {
            // Remove horizontal wall
            if (maze[x][y].south == 1) {
                maze[x][y].south = 0;
                maze[x][y + 1].north = 0;
            }
        } else {
            // Remove vertical wall
            if (maze[x][y].east == 1) {
                maze[x][y].east = 0;
                maze[x + 1][y].west = 0;
            }
        }
    }
}
// Initialize players
void initializePlayers() {
    // Player 1 (Blue)
    players[0].x = 1;
    players[0].y = 1;
    players[0].direction = 1;
    players[0].keyCount = 0;
    players[0].isVisible = true;
    players[0].color = (SDL_Color){0, 0, 255, 255};

    // Player 2 (Green)
    players[1].x = WIDTH - 2;
    players[1].y = HEIGHT - 2;
    players[1].direction = 3;
    players[1].keyCount = 0;
    players[1].isVisible = false;
    players[1].color = (SDL_Color){0, 255, 0, 255};
}

// Initialize keys
void initializeKeys() {
    for (int i = 0; i < MAX_KEYS; i++) {
        respawnKey(i);
        keys[i].isVisible = false;
    }
}

void respawnKey(int keyIndex) {
    do {
        keys[keyIndex].x = rand() % WIDTH;
        keys[keyIndex].y = rand() % HEIGHT;
    } while (maze[keys[keyIndex].x][keys[keyIndex].y].visited == 0);
    
    keys[keyIndex].isCollected = false;
}

// Update key visibility
void updateKeyVisibility() {
    Player currentP = players[currentPlayer];
    for (int i = 0; i < MAX_KEYS; i++) {
        if (!keys[i].isCollected) {
            int dx = abs(keys[i].x - currentP.x);
            int dy = abs(keys[i].y - currentP.y);
            keys[i].isVisible = (dx <= VISIBILITY_RANGE && dy <= VISIBILITY_RANGE);
        }
    }
}

// Check if movement is possible
bool canMove(int x, int y, int direction) {
    if (x < 0 || x >= WIDTH || y < 0 || y >= HEIGHT) return false;
    
    switch (direction) {
        case 0: return !maze[x][y].north;
        case 1: return !maze[x][y].east;
        case 2: return !maze[x][y].south;
        case 3: return !maze[x][y].west;
    }
    return false;
}

// Move player
void movePlayer(int playerIndex, int direction) {
    Player* p = &players[playerIndex];
    int newX = p->x;
    int newY = p->y;
    
    switch (direction) {
        case 0: newY--; break;
        case 1: newX++; break;
        case 2: newY++; break;
        case 3: newX--; break;
    }
    
    if (canMove(p->x, p->y, direction)) {
        p->x = newX;
        p->y = newY;
        p->direction = direction;
        stepsRemaining--;
    }
}

// Collect keys
void collectKeys() {
    Player* p = &players[currentPlayer];
    for (int i = 0; i < MAX_KEYS; i++) {
        if (!keys[i].isCollected && keys[i].x == p->x && keys[i].y == p->y) {
            keys[i].isCollected = true;
            p->keyCount++;
            respawnKey(i);
        }
    }
}

// Check for opponent
bool checkForOpponent() {
    if (players[currentPlayer].keyCount < 3) return false;
    
    Player* current = &players[currentPlayer];
    Player* opponent = &players[1 - currentPlayer];
    
    int dx = opponent->x - current->x;
    int dy = opponent->y - current->y;
    
    bool inRange = false;
    switch (current->direction) {
        case 0: // North
            inRange = (dy < 0 && dy >= -CHECK_RANGE && dx == 0);
            break;
        case 1: // East
            inRange = (dx > 0 && dx <= CHECK_RANGE && dy == 0);
            break;
        case 2: // South
            inRange = (dy > 0 && dy <= CHECK_RANGE && dx == 0);
            break;
        case 3: // West
            inRange = (dx < 0 && dx >= -CHECK_RANGE && dy == 0);
            break;
    }
    
    if (inRange) {
        int stepX = (dx == 0) ? 0 : dx / abs(dx);
        int stepY = (dy == 0) ? 0 : dy / abs(dy);
        int x = current->x;
        int y = current->y;
        
        while (x != opponent->x || y != opponent->y) {
            if (stepX > 0 && maze[x][y].east) return false;
            if (stepX < 0 && maze[x][y].west) return false;
            if (stepY > 0 && maze[x][y].south) return false;
            if (stepY < 0 && maze[x][y].north) return false;
            x += stepX;
            y += stepY;
        }
        return true;
    }
    return false;
}

// Render maze
void renderMaze(SDL_Renderer* renderer) {
    for (int x = 0; x < WIDTH; x++) {
        for (int y = 0; y < HEIGHT; y++) {
            int cellX = x * CELL_SIZE;
            int cellY = y * CELL_SIZE;
            
            // Draw walls with thicker lines
            SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
            
            if (maze[x][y].north) {
                SDL_Rect wall = {cellX, cellY, CELL_SIZE, 4};
                SDL_RenderFillRect(renderer, &wall);
            }
            if (maze[x][y].south) {
                SDL_Rect wall = {cellX, cellY + CELL_SIZE - 4, CELL_SIZE, 4};
                SDL_RenderFillRect(renderer, &wall);
            }
            if (maze[x][y].east) {
                SDL_Rect wall = {cellX + CELL_SIZE - 4, cellY, 4, CELL_SIZE};
                SDL_RenderFillRect(renderer, &wall);
            }
            if (maze[x][y].west) {
                SDL_Rect wall = {cellX, cellY, 4, CELL_SIZE};
                SDL_RenderFillRect(renderer, &wall);
            }
        }
    }
}

// Draw pumpkin shape
void drawPumpkin(SDL_Renderer* renderer, int x, int y) {
    int centerX = x * CELL_SIZE + CELL_SIZE/2;
    int centerY = y * CELL_SIZE + CELL_SIZE/2;
    int radius = CELL_SIZE/4;
    
    // Draw main body (circle)
    for (int w = -radius; w < radius; w++) {
        for (int h = -radius; h < radius; h++) {
            if (w*w + h*h <= radius*radius) {
                SDL_RenderDrawPoint(renderer, centerX + w, centerY + h);
            }
        }
    }
    
    // Draw stem
    SDL_Rect stem = {centerX - 2, centerY - radius - 5, 4, 5};
    SDL_RenderFillRect(renderer, &stem);
}

// Draw player with direction arrow
void drawPlayerArrow(SDL_Renderer* renderer, Player player) {
    int centerX = player.x * CELL_SIZE + CELL_SIZE/2;
    int centerY = player.y * CELL_SIZE + CELL_SIZE/2;
    int radius = CELL_SIZE/4;
    
    // Draw player circle
    SDL_SetRenderDrawColor(renderer, player.color.r, player.color.g, 
        player.color.b, player.color.a);
    for (int w = -radius; w < radius; w++) {
        for (int h = -radius; h < radius; h++) {
            if (w*w + h*h <= radius*radius) {
                SDL_RenderDrawPoint(renderer, centerX + w, centerY + h);
            }
        }
    }
    
    // Draw direction arrow
    int arrowLength = radius + 5;
    int arrowX = centerX;
    int arrowY = centerY;
    int targetX = centerX;
    int targetY = centerY;
    
    switch (player.direction) {
        case 0: targetY = centerY - arrowLength; break;
        case 1: targetX = centerX + arrowLength; break;
        case 2: targetY = centerY + arrowLength; break;
        case 3: targetX = centerX - arrowLength; break;
    }
    
    SDL_RenderDrawLine(renderer, arrowX, arrowY, targetX, targetY);
}

// Render functions
void renderPlayers(SDL_Renderer* renderer) {
    for (int i = 0; i < 2; i++) {
        if (players[i].isVisible) {
            drawPlayerArrow(renderer, players[i]);
        }
    }
}

void renderKeys(SDL_Renderer* renderer) {
    SDL_SetRenderDrawColor(renderer, 255, 165, 0, 255); // Orange
    for (int i = 0; i < MAX_KEYS; i++) {
        if (!keys[i].isCollected && keys[i].isVisible) {
            drawPumpkin(renderer, keys[i].x, keys[i].y);
        }
    }
}

void renderTurnIndicator(SDL_Renderer* renderer) {
    SDL_Rect textRect = {WIDTH * CELL_SIZE - 150, HEIGHT * CELL_SIZE - 30, 140, 20};
    SDL_SetRenderDrawColor(renderer, 128, 128, 128, 255);
    SDL_RenderFillRect(renderer, &textRect);
    
    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
    char turnText[32]; // Increased buffer size to 32
    snprintf(turnText, sizeof(turnText), "Player %d's Turn", currentPlayer + 1);
    // Note: In a real implementation, you'd use SDL_ttf to render text
}
void renderCheckEffect(SDL_Renderer* renderer) {
    if (!checkEffect.isCheckActive) return;
    
    Uint32 currentTime = SDL_GetTicks();
    if (currentTime - checkEffect.checkStartTime > CHECK_DURATION) {
        checkEffect.isCheckActive = false;
        return;
    }
    
    Player* p = &players[currentPlayer];
    int startX = p->x * CELL_SIZE + CELL_SIZE/2;
    int startY = p->y * CELL_SIZE + CELL_SIZE/2;
    int beamWidth = CELL_SIZE/2; // Width of the beam
    
    SDL_Rect beam;
    // Calculate beam dimensions based on direction
    switch (p->direction) {
        case 0: // North
            beam.x = startX - beamWidth/2;
            beam.y = startY - CHECK_RANGE * CELL_SIZE;
            beam.w = beamWidth;
            beam.h = CHECK_RANGE * CELL_SIZE;
            break;
        case 1: // East
            beam.x = startX;
            beam.y = startY - beamWidth/2;
            beam.w = CHECK_RANGE * CELL_SIZE;
            beam.h = beamWidth;
            break;
        case 2: // South
            beam.x = startX - beamWidth/2;
            beam.y = startY;
            beam.w = beamWidth;
            beam.h = CHECK_RANGE * CELL_SIZE;
            break;
        case 3: // West
            beam.x = startX - CHECK_RANGE * CELL_SIZE;
            beam.y = startY - beamWidth/2;
            beam.w = CHECK_RANGE * CELL_SIZE;
            beam.h = beamWidth;
            break;
    }
    
    // Set beam color with transparency (white with 50% opacity)
    SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 128);
    SDL_RenderFillRect(renderer, &beam);
    SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_NONE);}
int main(int argc, char* argv[]) {
    // Initialize SDL
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
        return 1;
    }

    // Create window first
    SDL_Window* window = SDL_CreateWindow("Maze Game", 
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        WIDTH * CELL_SIZE, HEIGHT * CELL_SIZE,
        SDL_WINDOW_SHOWN);

    if (window == NULL) {
        printf("Window could not be created! SDL_Error: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    // Enable alpha blending hint before creating renderer
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1");

    // Create renderer once with proper flags
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, 
        SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);

    if (renderer == NULL) {
        printf("Renderer could not be created! SDL_Error: %s\n", SDL_GetError());
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    // Initialize random seed
    srand(time(NULL));
    // Initialize game components
    initializeMaze();
    carvePath(0, 0);
  addExtraConnections();
    initializePlayers();
    initializeKeys();

    bool gameRunning = true;
    bool gameOver = false;
    SDL_Event event;

    while (gameRunning) {
        // Handle events
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                gameRunning = false;
            }
else if (event.type == SDL_KEYDOWN && !gameOver) {
    if (stepsRemaining > 0) {
        switch (event.key.keysym.sym) {
            case SDLK_w:  // Changed from SDLK_UP
                movePlayer(currentPlayer, 0);
                break;
            case SDLK_d:  // Changed from SDLK_RIGHT
                movePlayer(currentPlayer, 1);
                break;
            case SDLK_s:  // Changed from SDLK_DOWN
                movePlayer(currentPlayer, 2);
                break;
            case SDLK_a:  // Changed from SDLK_LEFT
                movePlayer(currentPlayer, 3);
                break;
        }
    }
    
    // Handle check action
    if (event.key.keysym.sym == SDLK_q || event.key.keysym.sym == SDLK_e) {  // Changed from SDLK_SPACE
        if (players[currentPlayer].keyCount >= 3) {
            players[currentPlayer].keyCount -= 3;
            checkEffect.isCheckActive = true;
            checkEffect.checkStartTime = SDL_GetTicks();
            checkEffect.checkDirection = players[currentPlayer].direction;
            
            if (checkForOpponent()) {
                gameOver = true;
            } else {
                stepsRemaining = 0; // End turn after check
            }
        }
    }
}        }

        // Update game state
        if (!gameOver) {
            updateKeyVisibility();
            collectKeys();

            // Check if turn should end
            if (stepsRemaining <= 0) {
                // Switch players
                currentPlayer = 1 - currentPlayer;
                stepsRemaining = 10;
                players[currentPlayer].isVisible = true;
                players[1 - currentPlayer].isVisible = false;
            }
        }

        // Render
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);

        // Render game elements
        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        renderMaze(renderer);
        renderKeys(renderer);
        renderPlayers(renderer);
        renderTurnIndicator(renderer);
        
        if (checkEffect.isCheckActive) {
            renderCheckEffect(renderer);
        }

        // Render game over message if applicable
        if (gameOver) {
            SDL_Rect messageRect = {WIDTH * CELL_SIZE / 4, HEIGHT * CELL_SIZE / 2 - 30, 
                                  WIDTH * CELL_SIZE / 2, 60};
            SDL_SetRenderDrawColor(renderer, 0, 0, 0, 200);
            SDL_RenderFillRect(renderer, &messageRect);
            SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
            SDL_RenderDrawRect(renderer, &messageRect);
            // Note: In a real implementation, you'd use SDL_ttf to render:
            // "Player X Wins!" where X is (currentPlayer + 1)
        }

        SDL_RenderPresent(renderer);

        // Cap frame rate
        SDL_Delay(16); // Approximately 60 FPS
    }

    // Cleanup
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}
