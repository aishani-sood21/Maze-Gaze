#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024

int main() {
    int server_fd, client1_socket, client2_socket;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);
    char buffer[BUFFER_SIZE] = {0};
    int turn = 1; // Track whose turn it is (1 for Client 1, 2 for Client 2)

    // Create a socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    // Set socket options
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    // Configure the address structure
    address.sin_family = AF_INET; // IPv4
    address.sin_addr.s_addr = INADDR_ANY; // Bind to all available interfaces
    address.sin_port = htons(PORT); // Convert port to network byte order

    // Bind the socket to the address
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    if (listen(server_fd, 2) < 0) {
        perror("Listen failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    printf("Server is listening on port %d\n", PORT);

    // Accept two clients
    client1_socket = accept(server_fd, (struct sockaddr*)&address, (socklen_t*)&addrlen);
    if (client1_socket < 0) {
        perror("Accept failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }
    printf("Client 1 connected.\n");

    client2_socket = accept(server_fd, (struct sockaddr*)&address, (socklen_t*)&addrlen);
    if (client2_socket < 0) {
        perror("Accept failed");
        close(client1_socket);
        close(server_fd);
        exit(EXIT_FAILURE);
    }
    printf("Client 2 connected.\n");

    // Game control loop
    while (1) {
        // Inform which client's turn it is
        if (turn == 1) {
            send(client1_socket, "Your turn. Enter control (single char, 'q' to quit): ", 54, 0);
            memset(buffer, 0, BUFFER_SIZE);
            int read_size = read(client1_socket, buffer, sizeof(buffer));
            if (read_size <= 0 || buffer[0] == 'q') {
                printf("Client 1 disconnected or quit.\n");
                break; // Exit the loop if Client 1 disconnects or sends 'q'
            }
            printf("Client 1 control: %c\n", buffer[0]);
            send(client2_socket, buffer, read_size, 0); // Send Client 1's input to Client 2
            turn = 2; // Switch to Client 2's turn
        } else {
            send(client2_socket, "Your turn. Enter control (single char, 'q' to quit): ", 54, 0);
            memset(buffer, 0, BUFFER_SIZE);
            int read_size = read(client2_socket, buffer, sizeof(buffer));
            if (read_size <= 0 || buffer[0] == 'q') {
                printf("Client 2 disconnected or quit.\n");
                break; // Exit the loop if Client 2 disconnects or sends 'q'
            }
            printf("Client 2 control: %c\n", buffer[0]);
            send(client1_socket, buffer, read_size, 0); // Send Client 2's input to Client 1
            turn = 1; // Switch to Client 1's turn
        }
    }

    // Notify both clients that the game is over
    send(client1_socket, "The game has ended. Exiting...\n", 32, 0);
    send(client2_socket, "The game has ended. Exiting...\n", 32, 0);

    // Cleanup and exit
    close(client1_socket);
    close(client2_socket);
    close(server_fd);
    return 0;
}
