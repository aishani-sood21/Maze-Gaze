#include "server.h"
#define PORT 8080

int main() {
    int server_fd, client1_socket, client2_socket;
    struct sockaddr_in address;

    init_server(&server_fd, &address);
    printf("Server is listening on port %d\n", PORT);
    accept_clients(server_fd, &client1_socket, &client2_socket);
    printf("Client 1 connected.\nClient 2 connected.\n");

    handle_game(client1_socket, client2_socket);

    close(client1_socket);
    close(client2_socket);
    close(server_fd);
    return 0;
}
