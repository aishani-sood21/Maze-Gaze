// server.h
#ifndef SERVER_H
#define SERVER_H

#include <sys/socket.h> // for socket functions
#include <netinet/in.h> // for sockaddr_in
#include <arpa/inet.h> // for inet_addr

void init_server(int *server_fd, struct sockaddr_in *address);
void accept_clients(int server_fd, int *client1_socket, int *client2_socket);
void handle_game(int client1_socket, int client2_socket);

#endif // SERVER_H
