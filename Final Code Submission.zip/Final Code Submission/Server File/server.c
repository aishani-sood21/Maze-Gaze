#include "server.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>

#define PORT 8080
#define BUFFER_SIZE 1024
#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600

void render(SDL_Renderer* renderer, int turn);
void handleInput(SDL_Event* event, int* turn, int client_socket);

int main() {
    // SDL Initialization
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
        return 1;
    }

    SDL_Window* window = SDL_CreateWindow("Turn-based Game", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, WINDOW_WIDTH, WINDOW_HEIGHT, 0);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    // Server code
    int server_fd, client1_socket, client2_socket;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);
    
    // Create a socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    // Set socket options
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    // Configure the address structure
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    // Bind the socket
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    if (listen(server_fd, 2) < 0) {
        perror("Listen failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    printf("Server is listening on port %d\n", PORT);

    // Accept two clients
    client1_socket = accept(server_fd, (struct sockaddr*)&address, (socklen_t*)&addrlen);
    if (client1_socket < 0) {
        perror("Accept failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }
    printf("Client 1 connected.\n");

    client2_socket = accept(server_fd, (struct sockaddr*)&address, (socklen_t*)&addrlen);
    if (client2_socket < 0) {
        perror("Accept failed");
        close(client1_socket);
        close(server_fd);
        exit(EXIT_FAILURE);
    }
    printf("Client 2 connected.\n");

    // Game control loop
    int turn = 1; // Track whose turn it is
    char buffer[BUFFER_SIZE] = {0};
    int running = 1;

    while (running) {
        // Notify the current player to take their turn
        if (turn == 1) {
            send(client1_socket, "Your turn! Enter command (u/d/q): ", 36, 0);
            recv(client1_socket, buffer, sizeof(buffer), 0);
            if (buffer[0] == 'q') {
                running = 0;
                break;
            }
            // Process input for Client 1
            // Example: Update state based on input
            printf("Client 1 command: %c\n", buffer[0]);
            send(client2_socket, buffer, strlen(buffer), 0); // Notify Client 2
            turn = 2; // Switch turn
        } else {
            send(client2_socket, "Your turn! Enter command (u/d/q): ", 36, 0);
            recv(client2_socket, buffer, sizeof(buffer), 0);
            if (buffer[0] == 'q') {
                running = 0;
                break;
            }
            // Process input for Client 2
            // Example: Update state based on input
            printf("Client 2 command: %c\n", buffer[0]);
            send(client1_socket, buffer, strlen(buffer), 0); // Notify Client 1
            turn = 1; // Switch turn
        }

        // Render the game
        render(renderer, turn);
    }

    // Notify both clients that the game is over
    send(client1_socket, "The game has ended. Exiting...\n", 32, 0);
    send(client2_socket, "The game has ended. Exiting...\n", 32, 0);

    // Cleanup
    close(client1_socket);
    close(client2_socket);
    close(server_fd);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    
    return 0;
}

void render(SDL_Renderer* renderer, int turn) {
    // Clear screen
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255); // Black
    SDL_RenderClear(renderer);

    // Set color based on whose turn it is
    if (turn == 1) {
        SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255); // Blue
    } else {
        SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255); // Green
    }

    // Example position of the character
    SDL_Rect character = { 100, 100, 50, 50 };
    SDL_RenderFillRect(renderer, &character);

    // Present the backbuffer
    SDL_RenderPresent(renderer);
}

