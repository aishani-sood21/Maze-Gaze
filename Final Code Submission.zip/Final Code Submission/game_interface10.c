#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include <stdbool.h>

// Screen dimensions
const int SCREEN_WIDTH = 640;
const int SCREEN_HEIGHT = 480;

// Button dimensions
const int BUTTON_WIDTH = 200;
const int BUTTON_HEIGHT = 50;

// Colors
SDL_Color buttonBaseColor = {169, 169, 169, 200};  // Greyish color for button with reduced transparency
SDL_Color buttonHoverColor = {105, 105, 105, 200}; // Darker grey on hover
SDL_Color textColor = {0, 0, 0, 255};              // Black for text

// Function to check if the mouse is over a button
bool isMouseOverButton(int x, int y, SDL_Rect buttonRect) {
    return x > buttonRect.x && x < buttonRect.x + buttonRect.w && y > buttonRect.y && y < buttonRect.y + buttonRect.h;
}

// Function to render text on button
void renderText(SDL_Renderer *renderer, TTF_Font *font, const char *text, SDL_Color color, SDL_Rect buttonRect) {
    SDL_Surface *textSurface = TTF_RenderText_Solid(font, text, color);
    SDL_Texture *textTexture = SDL_CreateTextureFromSurface(renderer, textSurface);

    // Center text in button
    int textWidth = textSurface->w;
    int textHeight = textSurface->h;
    SDL_Rect textRect = {
        buttonRect.x + (buttonRect.w - textWidth) / 2,
        buttonRect.y + (buttonRect.h - textHeight) / 2,
        textWidth,
        textHeight
    };

    SDL_RenderCopy(renderer, textTexture, NULL, &textRect);

    SDL_DestroyTexture(textTexture);
    SDL_FreeSurface(textSurface);
}

int main(int argc, char *argv[]) {
    // Initialize SDL, SDL_ttf, SDL_image, and SDL_mixer
    SDL_Init(SDL_INIT_VIDEO);
    TTF_Init();
    IMG_Init(IMG_INIT_PNG);
    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048);  // Initialize audio with specific format

    SDL_Window *window = SDL_CreateWindow("Game Interface", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
    SDL_Renderer *renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    // Load background image
    SDL_Surface *backgroundSurface = IMG_Load("background.png");
    if (!backgroundSurface) {
        printf("Failed to load background image: %s\n", IMG_GetError());
        return -1;
    }
    SDL_Texture *backgroundTexture = SDL_CreateTextureFromSurface(renderer, backgroundSurface);
    SDL_FreeSurface(backgroundSurface);

    // Load font
    TTF_Font *font = TTF_OpenFont("OpenSans.ttf", 24);
    if (!font) {
        printf("Failed to load font: %s\n", TTF_GetError());
        return -1;
    }

    // Load background music
    Mix_Music *music = Mix_LoadMUS("background.mp3");
    if (!music) {
        printf("Failed to load music: %s\n", Mix_GetError());
        return -1;
    }
    
    // Play the music in a loop (-1 means infinite looping)
    Mix_PlayMusic(music, -1);

    // Define button positions
    SDL_Rect newGameButton = {220, 150, BUTTON_WIDTH, BUTTON_HEIGHT};
    SDL_Rect exitGameButton = {220, 250, BUTTON_WIDTH, BUTTON_HEIGHT};

    bool quit = false;
    SDL_Event event;

    while (!quit) {
        // Event handling
        while (SDL_PollEvent(&event) != 0) {
            if (event.type == SDL_QUIT) {
                quit = true;
            } else if (event.type == SDL_MOUSEBUTTONDOWN) {
                int x, y;
                SDL_GetMouseState(&x, &y);
                if (isMouseOverButton(x, y, newGameButton)) {
                    printf("New Game button clicked!\n");
                }
                if (isMouseOverButton(x, y, exitGameButton)) {
                    printf("Exit Game button clicked!\n");
                    quit = true;
                }
            }
        }

        // Get mouse position
        int mouseX, mouseY;
        SDL_GetMouseState(&mouseX, &mouseY);

        // Render background image
        SDL_RenderCopy(renderer, backgroundTexture, NULL, NULL);

        // Render "New Game" button with hover effect
        if (isMouseOverButton(mouseX, mouseY, newGameButton)) {
            SDL_SetRenderDrawColor(renderer, buttonHoverColor.r, buttonHoverColor.g, buttonHoverColor.b, buttonHoverColor.a);
        } else {
            SDL_SetRenderDrawColor(renderer, buttonBaseColor.r, buttonBaseColor.g, buttonBaseColor.b, buttonBaseColor.a);
        }
        SDL_RenderFillRect(renderer, &newGameButton);
        renderText(renderer, font, "New Game", textColor, newGameButton);

        // Render "Exit Game" button with hover effect
        if (isMouseOverButton(mouseX, mouseY, exitGameButton)) {
            SDL_SetRenderDrawColor(renderer, buttonHoverColor.r, buttonHoverColor.g, buttonHoverColor.b, buttonHoverColor.a);
        } else {
            SDL_SetRenderDrawColor(renderer, buttonBaseColor.r, buttonBaseColor.g, buttonBaseColor.b, buttonBaseColor.a);
        }
        SDL_RenderFillRect(renderer, &exitGameButton);
        renderText(renderer, font, "Exit Game", textColor, exitGameButton);

        // Update screen
        SDL_RenderPresent(renderer);
    }

    // Clean up
    Mix_FreeMusic(music);              // Free the music
    SDL_DestroyTexture(backgroundTexture);
    TTF_CloseFont(font);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    Mix_CloseAudio();                  // Close audio
    TTF_Quit();
    IMG_Quit();
    SDL_Quit();

    return 0;
}
