#ifndef GAME_H
#define GAME_H

#include <SDL2/SDL.h> // Use SDL2 header

#define MAX_PLAYERS 4
#define MAX_KEYS 10
#define MAZE_WIDTH 20  // Define appropriate width
#define MAZE_HEIGHT 20 // Define appropriate height
#define VISIBILITY_RANGE 5

typedef struct {
    int x, y;
    int isCollected;
    int isVisible;
} Key;

typedef struct {
    char name[50];
    int x, y;
    int keyCount;
} Player;

typedef struct {
    // Define your maze cell properties here
    // Example:
    int isWall;
    int isVisible;
} MazeCell;

extern Player players[MAX_PLAYERS];
extern Key keys[MAX_KEYS];
extern MazeCell maze[MAZE_WIDTH][MAZE_HEIGHT]; // Define this appropriately

void debugLog(const char* format, ...);
void collectKeys();
void checkKeyCollection(int playerNumber);
void updateKeyVisibility(int playerNumber);
void updatePlayerVisibility(int playerNumber);
void renderMaze(SDL_Renderer* renderer);

#endif // GAME_H
