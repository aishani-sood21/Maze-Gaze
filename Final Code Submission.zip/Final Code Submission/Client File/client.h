// client.h
#ifndef CLIENT_H
#define CLIENT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <poll.h>
#include <fcntl.h>

#define PORT 8080
#define BUFFER_SIZE 1024

int connectToServer(const char* ip, int port);
void sendControlChar(int sock, char control_char);
int receiveMessage(int sock, char* message, size_t size);
void closeConnection(int sock);
void sendControlChar(int sock, char control_char);


#endif // CLIENT_H
