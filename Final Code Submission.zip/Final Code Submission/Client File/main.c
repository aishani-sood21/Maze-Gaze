#include <SDL2/SDL.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <stdbool.h>
#include <string.h>
#include "client.h"

// Constants
#define WIDTH 10
#define HEIGHT 10
#define CELL_SIZE 60
#define MAX_KEYS 12
#define CHECK_RANGE 4
#define VISIBILITY_RANGE 2
#define CHECK_DURATION 500
#define STEPS_PER_TURN 10

void updatePlayerVisibility(void);
void checkKeyCollection(void);
bool checkForOpponent(void);

void checkKeyCollection(void) {
    Player* p = &players[playerNumber];
    for (int i = 0; i < MAX_KEYS; i++) {
        if (!keys[i].isCollected && keys[i].isVisible &&
            keys[i].x == p->x && keys[i].y == p->y) {
            keys[i].isCollected = true;
            p->keyCount++;
            debugLog("%s collected a key! Total keys: %d", p->name, p->keyCount);
        }
    }
}
void renderMaze(void) {
    for (int x = 0; x < WIDTH; x++) {
        for (int y = 0; y < HEIGHT; y++) {
            SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255); // White color for the walls
            if (maze[x][y].north) {
                SDL_RenderDrawLine(renderer, x * CELL_SIZE, y * CELL_SIZE,
                                   (x + 1) * CELL_SIZE, y * CELL_SIZE); // North wall
            }
            if (maze[x][y].south) {
                SDL_RenderDrawLine(renderer, x * CELL_SIZE, (y + 1) * CELL_SIZE,
                                   (x + 1) * CELL_SIZE, (y + 1) * CELL_SIZE); // South wall
            }
            if (maze[x][y].east) {
                SDL_RenderDrawLine(renderer, (x + 1) * CELL_SIZE, y * CELL_SIZE,
                                   (x + 1) * CELL_SIZE, (y + 1) * CELL_SIZE); // East wall
            }
            if (maze[x][y].west) {
                SDL_RenderDrawLine(renderer, x * CELL_SIZE, y * CELL_SIZE,
                                   x * CELL_SIZE, (y + 1) * CELL_SIZE); // West wall
            }
        }
    }
}
void updateKeyVisibility(void) {
    Player* p = &players[playerNumber];
    for (int i = 0; i < MAX_KEYS; i++) {
        if (!keys[i].isCollected) {
            if (abs(keys[i].x - p->x) <= VISIBILITY_RANGE &&
                abs(keys[i].y - p->y) <= VISIBILITY_RANGE) {
                keys[i].isVisible = true; // Make key visible if within range
            } else {
                keys[i].isVisible = false; // Hide key if out of range
            }
        }
    }
}

void updatePlayerVisibility(void) {
    Player* p = &players[playerNumber];
    for (int x = p->x - VISIBILITY_RANGE; x <= p->x + VISIBILITY_RANGE; x++) {
        for (int y = p->y - VISIBILITY_RANGE; y <= p->y + VISIBILITY_RANGE; y++) {
            if (x >= 0 && x < WIDTH && y >= 0 && y < HEIGHT) {
                maze[x][y].visited = 1; // Marking the cells as visible
            }
        }
    }
}

// Game structures
typedef struct {
    int visited;
    int north, south, east, west;
} Cell;

typedef struct {
    int x, y;
    int direction;  // 0:North, 1:East, 2:South, 3:West
    int keyCount;
    bool isVisible;
    SDL_Color color;
    char name[32];
} Player;

typedef struct {
    int x, y;
    bool isVisible;
    bool isCollected;
} Key;

typedef struct {
    bool isCheckActive;
    Uint32 checkStartTime;
    int checkX, checkY;
} CheckEffect;

typedef enum {
    GAME_STATE_CONNECTING,
    GAME_STATE_WAITING,
    GAME_STATE_PLAYING,
    GAME_STATE_GAME_OVER
} GameState;

typedef enum {
    MSG_CONNECT,
    MSG_START,
    MSG_MOVE,
    MSG_CHECK,
    MSG_TURN,
    MSG_GAME_STATE,
    MSG_GAME_OVER
} MessageType;

typedef struct {
    MessageType type;
    int playerIndex;
    int x, y;
    int direction;
    int keyCount;
    bool gameOver;
    char data[256];
} GameMessage;

// Global variables
Cell maze[WIDTH][HEIGHT];
Player players[2];
Key keys[MAX_KEYS];
CheckEffect checkEffect = {false, 0, 0, 0};
int currentPlayer = 0;
int stepsRemaining = STEPS_PER_TURN;
int networkSocket = -1;
int playerNumber = -1;
GameState gameState = GAME_STATE_CONNECTING;
SDL_Window* window = NULL;
SDL_Renderer* renderer = NULL;

// Function prototypes
void initializeGame(void);
void handleNetwork(void);
void processGameLogic(void);
void renderGame(void);
void cleanup(void);

void debugLog(const char* format, ...) {
    va_list args;
    va_start(args, format);
    printf("[DEBUG] ");
    vprintf(format, args);
    printf("\n");
    va_end(args);
    fflush(stdout);
}

// Maze generation functions
void initializeMaze(void) {
    for (int x = 0; x < WIDTH; x++) {
        for (int y = 0; y < HEIGHT; y++) {
            maze[x][y] = (Cell){0, 1, 1, 1, 1};
        }
    }
}

void carvePath(int x, int y) {
    maze[x][y].visited = 1;
    int directions[4][2] = {{0, -1}, {0, 1}, {1, 0}, {-1, 0}};
    int randomOrder[4] = {0, 1, 2, 3};
    
    for (int i = 0; i < 4; i++) {
        int j = rand() % 4;
        int temp = randomOrder[i];
        randomOrder[i] = randomOrder[j];
        randomOrder[j] = temp;
    }
    
    for (int i = 0; i < 4; i++) {
        int dir = randomOrder[i];
        int nx = x + directions[dir][0];
        int ny = y + directions[dir][1];
        
        if (nx >= 0 && nx < WIDTH && ny >= 0 && ny < HEIGHT && !maze[nx][ny].visited) {
            switch (dir) {
                case 0:
                    maze[x][y].north = 0;
                    maze[nx][ny].south = 0;
                    break;
                case 1:
                    maze[x][y].south = 0;
                    maze[nx][ny].north = 0;
                    break;
                case 2:
                    maze[x][y].east = 0;
                    maze[nx][ny].west = 0;
                    break;
                case 3:
                    maze[x][y].west = 0;
                    maze[nx][ny].east = 0;
                    break;
            }
            carvePath(nx, ny);
        }
    }
}

void addExtraConnections(void) {
    int numExtraConnections = (WIDTH * HEIGHT) / 4;
    for (int i = 0; i < numExtraConnections; i++) {
        int x = rand() % (WIDTH - 1);
        int y = rand() % HEIGHT;
        
        if (rand() % 2 == 0 && y < HEIGHT - 1) {
            maze[x][y].south = 0;
            maze[x][y + 1].north = 0;
        } else if (x < WIDTH - 1) {
            maze[x][y].east = 0;
            maze[x + 1][y].west = 0;
        }
    }
}

// Player and key functions
void initializePlayers(void) {
    debugLog("Initializing players");
    
    // Initialize player 1
    players[0] = (Player){
        .x = 1,
        .y = 1,
        .direction = 1,
        .keyCount = 0,
        .isVisible = true,
        .color = {0, 0, 255, 255}
    };
    strncpy(players[0].name, "Player 1", sizeof(players[0].name) - 1);

    // Initialize player 2
    players[1] = (Player){
        .x = WIDTH-2,
        .y = HEIGHT-2,
        .direction = 3,
        .keyCount = 0,
        .isVisible = true,
        .color = {0, 255, 0, 255}
    };
    strncpy(players[1].name, "Player 2", sizeof(players[1].name) - 1);

    currentPlayer = 0;
    stepsRemaining = STEPS_PER_TURN;
}

void initializeKeys(void) {
    debugLog("Initializing keys");
    for (int i = 0; i < MAX_KEYS; i++) {
        do {
            keys[i].x = rand() % WIDTH;
            keys[i].y = rand() % HEIGHT;
        } while ((keys[i].x == players[0].x && keys[i].y == players[0].y) ||
                 (keys[i].x == players[1].x && keys[i].y == players[1].y));
        keys[i].isCollected = false;
        keys[i].isVisible = false;
    }
}


void respawnKey(int keyIndex) {
    do {
        keys[keyIndex].x = rand() % WIDTH;
        keys[keyIndex].y = rand() % HEIGHT;
    } while ((keys[keyIndex].x == players[0].x && keys[keyIndex].y == players[0].y) ||
             (keys[keyIndex].x == players[1].x && keys[keyIndex].y == players[1].y));
    keys[keyIndex].isCollected = false;
}

// Network functions
void serializeGameMessage(const GameMessage* msg, char* buffer) {
    snprintf(buffer, BUFFER_SIZE, "%d,%d,%d,%d,%d,%d,%d,%s",
             msg->type, msg->playerIndex, msg->x, msg->y,
             msg->direction, msg->keyCount, msg->gameOver, msg->data);
}

void deserializeGameMessage(const char* buffer, GameMessage* msg) {
    sscanf(buffer, "%d,%d,%d,%d,%d,%d,%d,%[^\n]",
           (int*)&msg->type, &msg->playerIndex, &msg->x, &msg->y,
           &msg->direction, &msg->keyCount, (int*)&msg->gameOver, msg->data);
}

void sendGameState(void) {
    GameMessage msg = {
        .type = MSG_GAME_STATE,
        .playerIndex = playerNumber,
        .x = players[playerNumber].x,
        .y = players[playerNumber].y,
        .direction = players[playerNumber].direction,
        .keyCount = players[playerNumber].keyCount,
        .gameOver = false
    };
    
    char buffer[BUFFER_SIZE];
    serializeGameMessage(&msg, buffer);
    send(networkSocket, buffer, strlen(buffer), 0);
}


void handleNetworkMessage(const char* message) {
    debugLog("Handling network message: %s", message);
    
    GameMessage msg;
    deserializeGameMessage(message, &msg);
    
    switch (msg.type) {
        case MSG_CONNECT:
            playerNumber = msg.playerIndex;
            gameState = GAME_STATE_WAITING;
            debugLog("Connected as player %d", playerNumber);
            break;
            
        case MSG_START:
            gameState = GAME_STATE_PLAYING;
            debugLog("Game started");
            break;
            
        case MSG_MOVE:
            if (msg.playerIndex != playerNumber) {
                players[msg.playerIndex].x = msg.x;
                players[msg.playerIndex].y = msg.y;
                players[msg.playerIndex].direction = msg.direction;
                debugLog("Player %d moved to (%d, %d)", msg.playerIndex, msg.x, msg.y);
            }
            break;
            
        case MSG_CHECK:
            if (msg.playerIndex != playerNumber) {
                checkEffect.isCheckActive = true;
                checkEffect.checkStartTime = SDL_GetTicks();
                checkEffect.checkX = msg.x;
                checkEffect.checkY = msg.y;
                players[msg.playerIndex].keyCount = msg.keyCount;
                
                if (msg.gameOver) {
                    gameState = GAME_STATE_GAME_OVER;
                    debugLog("Game over triggered by check");
                }
            }
            break;
            
        case MSG_TURN:
            currentPlayer = msg.playerIndex;
            stepsRemaining = STEPS_PER_TURN;
            debugLog("Turn changed to player %d", currentPlayer);
            break;
            
        case MSG_GAME_OVER:
            gameState = GAME_STATE_GAME_OVER;
            debugLog("Game over message received");
            break;
    }
}

// Game logic functions
bool canMove(int x, int y, int direction) {
    if (x < 0 || x >= WIDTH || y < 0 || y >= HEIGHT) return false;
    
    switch (direction) {
        case 0: return !maze[x][y].north;
        case 1: return !maze[x][y].east;
        case 2: return !maze[x][y].south;
        case 3: return !maze[x][y].west;
        default: return false;
    }
}

void movePlayer(int direction) {
    if (gameState != GAME_STATE_PLAYING || currentPlayer != playerNumber) {
        debugLog("Move rejected - Not current player or wrong game state");
        return;
    }
    
    if (stepsRemaining <= 0) {
        debugLog("No steps remaining for this turn");
        return;
    }
    
    Player* p = &players[playerNumber];
    int newX = p->x;
    int newY = p->y;
    
    // Calculate new position based on direction
    switch (direction) {
        case 0: // North
            if (!maze[p->x][p->y].north) newY--;
            break;
        case 1: // East
            if (!maze[p->x][p->y].east) newX++;
            break;
        case 2: // South
            if (!maze[p->x][p->y].south) newY++;
            break;
        case 3: // West
            if (!maze[p->x][p->y].west) newX--;
            break;
    }
    
    // Check if the new position is valid
    if (newX >= 0 && newX < WIDTH && newY >= 0 && newY < HEIGHT) {
        // Update position
        p->x = newX;
        p->y = newY;
        p->direction = direction;
        stepsRemaining--;
        
        debugLog("Player %d moved to (%d, %d), Steps remaining: %d", 
                playerNumber, newX, newY, stepsRemaining);
        
        // Check for key collection
        checkKeyCollection();
        
        // Update visibility
        updatePlayerVisibility();
        
        // Send movement to network
        GameMessage msg = {
            .type = MSG_MOVE,
            .playerIndex = playerNumber,
            .x = newX,
            .y = newY,
            .direction = direction,
            .keyCount = p->keyCount
        };
        
        char buffer[BUFFER_SIZE];
        serializeGameMessage(&msg, buffer);
        if (send(networkSocket, buffer, strlen(buffer), 0) < 0) {
            debugLog("Failed to send movement message");
        }
        
        // If no steps remaining, end turn
        if (stepsRemaining <= 0) {
            GameMessage turnMsg = {
                .type = MSG_TURN,
                .playerIndex = (playerNumber + 1) % 2
            };
            serializeGameMessage(&turnMsg, buffer);
            if (send(networkSocket, buffer, strlen(buffer), 0) < 0) {
                debugLog("Failed to send turn message");
            }
        }
    } else {
        debugLog("Move rejected - Out of bounds");
    }
}


void renderPlayers(void) {
    for (int i = 0; i < 2; i++) {
        SDL_SetRenderDrawColor(renderer, 
                              players[i].color.r,
                              players[i].color.g,
                              players[i].color.b,
                              players[i].color.a);
                              
        SDL_Rect playerRect = {
            players[i].x * CELL_SIZE + CELL_SIZE/4,
            players[i].y * CELL_SIZE + CELL_SIZE/4,
            CELL_SIZE/2,
            CELL_SIZE/2
        };
        SDL_RenderFillRect(renderer, &playerRect);
    }
}

void renderKeys(void) {
    SDL_SetRenderDrawColor(renderer, 255, 255, 0, 255);
    for (int i = 0; i < MAX_KEYS; i++) {
        if (keys[i].isVisible && !keys[i].isCollected) {
            SDL_Rect keyRect = {
                keys[i].x * CELL_SIZE + CELL_SIZE/3,
                keys[i].y * CELL_SIZE + CELL_SIZE/3,
                CELL_SIZE/3,
                CELL_SIZE/3
            };
            SDL_RenderFillRect(renderer, &keyRect);
        }
    }
}

void renderGame(void) {
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderClear(renderer);
    
    renderMaze();
    renderPlayers();
    renderKeys();
    
    if (checkEffect.isCheckActive) {
        Uint32 elapsed = SDL_GetTicks() - checkEffect.checkStartTime;
        if (elapsed < CHECK_DURATION) {
            SDL_SetRenderDrawColor(renderer, 255, 0, 0, 128);
            SDL_Rect checkRect = {
                checkEffect.checkX * CELL_SIZE,
                checkEffect.checkY * CELL_SIZE,
                CELL_SIZE,
                CELL_SIZE
            };
            SDL_RenderFillRect(renderer, &checkRect);
        } else {
            checkEffect.isCheckActive = false;
        }
    }
    
    SDL_RenderPresent(renderer);
}

// Main game functions
void initializeGame(void) {
    srand(time(NULL));
    
    initializeMaze();
    carvePath(0, 0);
    addExtraConnections();
    initializePlayers();
    initializeKeys();
    
    gameState = GAME_STATE_CONNECTING;
}

void cleanup(void) {
    if (networkSocket >= 0) {
        closeConnection(networkSocket);
    }
    if (renderer) {
        SDL_DestroyRenderer(renderer);
    }
    if (window) {
        SDL_DestroyWindow(window);
    }
    SDL_Quit();
}

void handleInput(void) {
    const Uint8 *state = SDL_GetKeyboardState(NULL);
    
    if (gameState != GAME_STATE_PLAYING) {
        return;
    }
    
    if (currentPlayer != playerNumber) {
        return;
    }

    if (state[SDL_SCANCODE_W]) {
        debugLog("Moving North");
        movePlayer(0);
        sendControlChar(networkSocket, 'W');  // Send 'W' for move North
    }
    if (state[SDL_SCANCODE_D]) {
        debugLog("Moving East");
        movePlayer(1);
        sendControlChar(networkSocket, 'D');  // Send 'D' for move East
    }
    if (state[SDL_SCANCODE_S]) {
        debugLog("Moving South");
        movePlayer(2);
        sendControlChar(networkSocket, 'S');  // Send 'S' for move South
    }
    if (state[SDL_SCANCODE_A]) {
        debugLog("Moving West");
        movePlayer(3);
        sendControlChar(networkSocket, 'A');  // Send 'A' for move West
    }
    if (state[SDL_SCANCODE_E] || state[SDL_SCANCODE_Q]) {
        if (players[playerNumber].keyCount >= 3) {
            debugLog("Initiating check action");
            sendControlChar(networkSocket, 'E');  // Send 'E' for check action
        } else {
            debugLog("Check action failed - Not enough keys (%d/3)", 
                    players[playerNumber].keyCount);
        }
    }
}

void processNetworkMessages(void) {
    char buffer[BUFFER_SIZE];
    int bytesReceived;

    // Non-blocking receive
    while ((bytesReceived = receiveMessage(networkSocket, buffer, BUFFER_SIZE - 1)) > 0) {
        buffer[bytesReceived] = '\0';
        handleNetworkMessage(buffer);
    }
}

void updateGameState(void) {
    if (gameState == GAME_STATE_PLAYING) {
        updateKeyVisibility();
        collectKeys();
        
        // Check if turn should end
        if (stepsRemaining <= 0) {
            GameMessage msg = {
                .type = MSG_TURN,
                .playerIndex = (currentPlayer + 1) % 2
            };
            char buffer[BUFFER_SIZE];
            serializeGameMessage(&msg, buffer);
            send(networkSocket, buffer, strlen(buffer), 0);
        }
    }
}

int main(int argc, char* argv[]) {
    // Initialize SDL
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("SDL initialization failed: %s\n", SDL_GetError());
        return 1;
    }
    
    // Create window
    window = SDL_CreateWindow("Maze Game", 
                            SDL_WINDOWPOS_UNDEFINED, 
                            SDL_WINDOWPOS_UNDEFINED,
                            WIDTH * CELL_SIZE, 
                            HEIGHT * CELL_SIZE,
                            SDL_WINDOW_SHOWN);
    if (!window) {
        printf("Window creation failed: %s\n", SDL_GetError());
        cleanup();
        return 1;
    }
    
    // Create renderer
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer) {
        printf("Renderer creation failed: %s\n", SDL_GetError());
        cleanup();
        return 1;
    }
    
    // Connect to server
    networkSocket = connectToServer("127.0.0.1", PORT);
    if (networkSocket < 0) {
        printf("Failed to connect to server\n");
        cleanup();
        return 1;
    }
    
    // Make socket non-blocking
    int flags = fcntl(networkSocket, F_GETFL, 0);
    fcntl(networkSocket, F_SETFL, flags | O_NONBLOCK);
    
    // Initialize game
    initializeGame();
    
    // Main game loop
    bool running = true;
    SDL_Event event;
    Uint32 lastFrameTime = SDL_GetTicks();
    
    while (running) {
    // Handle events
    while (SDL_PollEvent(&event)) {
        if (event.type == SDL_QUIT) {
            running = false;
        }
    }
    
    // Handle input
    handleInput();
    
    // Process network messages
    processNetworkMessages();
    
    // Update game state
    updateGameState();
    
    // Render
    renderGame();
    
    // Cap frame rate
    Uint32 currentFrameTime = SDL_GetTicks();
    Uint32 deltaTime = currentFrameTime - lastFrameTime;
    if (deltaTime < 16) {  // Target ~60 FPS
        SDL_Delay(16 - deltaTime);
    }
    lastFrameTime = currentFrameTime;
}

    
    cleanup();
    return 0;
}