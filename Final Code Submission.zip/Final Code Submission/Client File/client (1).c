#include "client.h"
#include <fcntl.h>
#include <termios.h>
#include <stdio.h>
#include <unistd.h>

void setNonBlockingMode() {
    struct termios oldt, newt;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO); // Disable canonical mode and echo
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
}

void resetTerminal() {
    struct termios oldt;
    tcgetattr(STDIN_FILENO, &oldt);
    oldt.c_lflag |= (ICANON | ECHO); // Enable canonical mode and echo
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
}

int main() {
    int sock = connectToServer("127.0.0.1", PORT);
    if (sock < 0) return -1;

    setNonBlockingMode();

    char control_char;
    char message[BUFFER_SIZE];

    while (1) {
        // Check for messages from the server
        int bytes_received = receiveMessage(sock, message, sizeof(message));
        if (bytes_received > 0) {
            message[bytes_received] = '\0'; // Null-terminate the string
            printf("Server: %s\n", message);

            // Check for turn prompt
            if (strncmp(message, "Your turn!", 10) == 0) {
                // Read input without needing to press enter
                if (read(STDIN_FILENO, &control_char, 1) == 1) {
                    sendControlChar(sock, control_char);
                    if (control_char == 'q') {
                        break; // Quit the game if 'q' is pressed
                    }
                }
            }
        }
    }

    resetTerminal();
    closeConnection(sock);
    return 0;
}
